import base64
import json
import logging
import typing
from abc import abstractmethod

import mqttools as mqtt
from mqttools import Message

from .model import MessageModel
from .utils import gzip_data

logger = logging.getLogger(__name__)


class MQTTWorker(mqtt.Client):
    pass


class MQTTPublisher(MQTTWorker):
    def on_publish(self, flags, payload):
        try:
            logger.info(f"Message published to {self._subscriptions} with {payload}")
        except ValueError:
            pass

    def send(self, topic: str, message: bytes | str | typing.Any):
        logger.info(f"Publishing message to {topic} - {message}")

        if isinstance(message, dict):
            message = json.dumps(message).encode("ascii")

        if isinstance(message, str):
            message = message.encode("ascii")

        self.publish(Message(topic=topic, message=message))


class MQTTSubscriber(MQTTWorker):
    async def on_message(self, message):
        await self._messages.put(message)

    @abstractmethod
    async def get_message(self):
        pass

    @staticmethod
    async def handle_error(error,
                           data: MessageModel,
                           retry_publisher: MQTTPublisher,
                           dead_letter_publisher: MQTTPublisher,
                           is_zip: bool = False):
        retry = data.metadata.retry
        topic = data.topic
        data.error = str(error)
        if retry > 0:
            logger.info(f"Retrying message: {retry}")
            data.metadata.retry = retry - 1
            await retry_publisher.start()
            msg = gzip_data(json.dumps(data.dict())) if is_zip else json.dumps(data.dict()).encode("ascii")
            retry_publisher.send(topic.target, msg)
            await retry_publisher.stop()
            return

        logger.error(f"Dead letter message: {retry}")
        await dead_letter_publisher.start()
        msg = gzip_data(json.dumps(data.dict())) if is_zip else json.dumps(data.dict()).encode("ascii")
        dead_letter_publisher.send(topic.failed, msg)
        await dead_letter_publisher.stop()
